# Sistema de Seguimiento de EMO — prototipo

Aplicación piloto en Python para organizar fechas de vencimiento de exámenes médicos ocupacionales, filtrar registros, identificar acciones prioritarias y exportar reportes.

## Requisitos
- Python 3.10 o posterior
- Acceso autorizado a los datos y aprobación de TI/SST antes de usar información real

## Instalación
1. Instala Python desde https://www.python.org/downloads/
2. Descomprime la carpeta del proyecto.
3. Abre una terminal en la carpeta y ejecuta:

```bash
pip install -r requirements.txt
streamlit run app.py
```

4. Se abrirá la aplicación en el navegador local.

## Columnas requeridas en Excel/CSV
- `Codigo`
- `Proyecto`
- `Puesto`
- `Fecha_vencimiento` (formato recomendado YYYY-MM-DD)
- `Responsable`
- `Correo_responsable`
- `Estado_aptitud`

Convierte el registro a datos mínimos necesarios. No incluyas diagnósticos, historias clínicas ni resultados clínicos detallados.

## Limitaciones
- Esta versión no envía correos automáticamente ni se conecta a SharePoint.
- Las alertas se calculan dentro de la aplicación al abrirla.
- No determina aptitud médica; la validación corresponde a los responsables autorizados.
- Para producción, requiere revisión de TI, seguridad, privacidad, permisos, licencias y política de retención de Applus+.
